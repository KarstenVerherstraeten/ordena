<!DOCTYPE html>
<html>
<head>
    <title>Geen toegang</title>
</head>
<body style="text-align: center; margin-top: 50px;">
<h1>Geen toegang</h1>
<p>Je hebt geen toegang tot deze pagina.</p>
<button onclick="window.history.back()" style="padding: 10px 20px; margin-top: 20px;">← Ga terug</button>
</body>
</html>
