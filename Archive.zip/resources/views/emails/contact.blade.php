<p><strong>Name:</strong> {{$ContactName}}</p>
<p><strong>Email:</strong> {{ $ContactEmail}}</p>
<p><strong>Message:</strong></p>
<p>{{ $ContactMessage}}</p>
